var app = angular.module('index-bienes', [])

app.controller('bienes', function($scope, $http){

	$scope.hola ='Hola mundo';

});