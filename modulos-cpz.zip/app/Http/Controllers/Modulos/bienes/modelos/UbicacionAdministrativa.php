<?php

namespace App\App\Http\Controllers\Modulos\bienes\modelos;

use Illuminate\Database\Eloquent\Model;

class UbicacionAdministrativa extends Model
{
    //
}
