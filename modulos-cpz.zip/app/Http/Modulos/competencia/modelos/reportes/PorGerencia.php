<?php

namespace App\Http\Modulos\competencia\modelos\reportes;

use Illuminate\Database\Eloquent\Model;

class PorGerencia extends Model
{
    //
}
